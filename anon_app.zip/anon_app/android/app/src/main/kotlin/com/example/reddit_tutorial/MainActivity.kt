package com.example.reddit_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
